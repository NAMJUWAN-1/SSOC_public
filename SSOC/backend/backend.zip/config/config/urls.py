"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/auth/", include("local_apps.tokens.urls")),
    path("api/auth/mm/", include("local_apps.oauth_accounts.urls")),
    path("api/users/", include("local_apps.users.urls")),
    path("api/channels/", include("local_apps.channels.urls")),
    path("api/search-logs/", include("local_apps.search_logs.urls")),
    path("api/posts/", include("local_apps.posts.urls")),
    path("api/archives/", include("local_apps.archives.urls")),
    path("api/calendar-events/", include("local_apps.calendar_events.urls")),
]
