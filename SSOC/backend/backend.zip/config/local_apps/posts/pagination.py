from rest_framework.pagination import PageNumberPagination


class PostPagination(PageNumberPagination):
    # 프론트에서 요청할 페이지 번호 파라미터 (?page=1)
    page_query_param = "page"

    # 한 페이지에 몇 개의 공지를 받을지 (?size=10)
    page_size_query_param = "size"

    # size로 요청할 수 있는 최대 공지 개수 (과도한 조회 방지)
    max_page_size = 100

    # size 파라미터가 없을 때 기본으로 내려줄 공지 개수
    page_size = 10
