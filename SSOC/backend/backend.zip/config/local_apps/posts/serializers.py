from rest_framework import serializers
from local_apps.posts.models import Post


class PostListSerializer(serializers.ModelSerializer):
    """
    공지 목록 조회용 Serializer
    - 메인페이지, 리스트 화면에서 사용
    - 상세 정보 없이 목록에 필요한 최소 필드만 반환
    """

    # FK 객체 전체가 아니라 ID 값만 내려주기 위한 필드
    channel_id = serializers.IntegerField(source="channel_id", read_only=True)
    category_id = serializers.IntegerField(source="category_id", read_only=True)

    class Meta:
        model = Post
        fields = [
            "post_id",      # 공지 ID
            "channel_id",   # 소속 채널 ID
            "category_id",  # 카테고리 ID
            "title",        # 공지 제목 (AI 생성)
            "content",      # 정제된 공지 내용 (목록용)
            "created_at",   # 생성 시각
            "updated_at",   # 수정 시각
        ]


class PostDetailSerializer(serializers.ModelSerializer):
    """
    공지 상세 조회용 Serializer
    - 공지 클릭 시 상세 팝업/페이지에서 사용
    - 현재는 List와 동일 필드지만,
      이후 상세 전용 필드가 생길 것을 고려해 분리
    """

    channel_id = serializers.IntegerField(source="channel_id", read_only=True)
    category_id = serializers.IntegerField(source="category_id", read_only=True)

    class Meta:
        model = Post
        fields = [
            "post_id",      # 공지 ID
            "channel_id",   # 소속 채널 ID
            "category_id",  # 카테고리 ID
            "title",        # 공지 제목
            "content",      # 공지 전체 내용
            "created_at",   # 생성 시각
            "updated_at",   # 수정 시각
        ]
